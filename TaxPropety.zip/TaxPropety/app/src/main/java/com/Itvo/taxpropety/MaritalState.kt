package com.Itvo.taxpropety

enum class MaritalState {
    Single,
    Married,
    Divorced,
    Widower

}
