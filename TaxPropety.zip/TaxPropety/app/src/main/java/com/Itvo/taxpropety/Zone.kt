package com.Itvo.taxpropety

data class Zone(
    val key: String,
    val Zone: String,
    val costForSquareMeter: Double
)
