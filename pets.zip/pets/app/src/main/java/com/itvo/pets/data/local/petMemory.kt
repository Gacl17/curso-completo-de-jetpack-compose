package com.itvo.pets.data.local

import com.itvo.pets.R
import com.itvo.pets.domain.PetType
import com.itvo.pets.domain.petModel

object petMemory {
    fun getPets(): List<petModel> {
        val pets = listOf(
            petModel(
                name = "Solovino",
                description = "black dog",
                type = PetType.DOG,
                image = R.drawable.perro
            ),
            petModel(
                name = "Mochi",
                description = "Person whit from",
                type = PetType.CAT,
                image = R.drawable.gato
            ),
            petModel(
                name = "Ka",
                description = "python",
                type = PetType.SNAKE,
                image = R.drawable.phyton
            )
        )
        return pets
    }
}