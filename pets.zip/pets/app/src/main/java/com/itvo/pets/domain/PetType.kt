package com.itvo.pets.domain

enum class PetType{
    DOG,
    CAT,
    SNAKE
}
