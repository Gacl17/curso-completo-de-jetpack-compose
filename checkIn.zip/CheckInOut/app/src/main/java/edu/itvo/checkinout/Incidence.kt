package edu.itvo.checkinout

data class Incidence(
    val delays: Int,
    val absences: Int,
    val permissions: Int
)