package edu.itvo.checkinout

enum class AcademicDegree {
    PRIMARY,
    SECONDARY,
    HIGH_SCHOOL,
    ASSOCIATE,
    BACHELOR,
    MASTER,
    DOCTORATE,
    POSTDOCTORAL
}