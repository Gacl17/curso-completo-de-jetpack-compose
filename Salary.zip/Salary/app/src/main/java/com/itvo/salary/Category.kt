package com.itvo.salary

enum class Category {
    UNO,
    DOS,
    TRES
}